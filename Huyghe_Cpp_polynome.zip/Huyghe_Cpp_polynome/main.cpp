#include <iostream>
#include <iomanip>
#include "term.h"
#include "poly.h"
#include "multiplier.h"
#include "printer.h"

using namespace std;

int main()
{
    unsigned int option;
    unsigned int option2;
    unsigned int option3;
    int coeff;
    char var;
    int pow;
    char yn;
    term term1 = term();
    term term2 = term();
    term term3 = term();
    term term4 = term();
    term term5 = term();
    term term6 = term();
    term term7 = term();
    term term8 = term();
    term term9 = term();
    term term10 = term();
    poly pola = poly();
    poly polb = poly();


    cout << "Press 1 to calcul or 2 to quit" << endl;
    cin >> option;
    switch(option)
    {
    case 1:
        cout << "       Welcome !" << endl;
        cout << "\nEnter 1 to continue, 2 to exit" << endl;
        cin >> option2;
        switch(option2)
        {
            case 1:
                {
                    {cout << "   Let's start !" << endl;
                    cout << "\nWe enter the polynomes term by term" << endl;
                    cout << "\nHere we are defining the first polynome" << endl;

                    cout << "\nCoefficient ? ";
                    cin >> coeff;
                    cout << "\nVariable ? ";
                    cin >> var;
                    cout << "\nPower ? " << endl;
                    cin >> pow;
                    term term1 = term(coeff,var,pow);
                    cout << "\nPass to the second polynome ? Press y if yes, or n if no : " << endl;
                    cin >> yn;
                    if(yn == 'y')
                        {
                            pola.setPoly(term1,term2,term3,term4,term5);
                            goto SecondPoly;
                        }

                    cout << "\nCoefficient ? ";
                    cin >> coeff;
                    cout << "\nVariable ? ";
                    cin >> var;
                    cout << "\nPower ? " << endl;
                    cin >> pow;
                    term term2 = term(coeff,var,pow);
                    cout << "\nPass to the second polynome ? Press y if yes, or n if no : " << endl;
                    cin >> yn;
                    if(yn == 'y')
                        {
                            pola.setPoly(term1,term2,term3,term4,term5);
                            goto SecondPoly;
                        }



                    cout << "\nCoefficient ? ";
                    cin >> coeff;
                    cout << "\nVariable ? ";
                    cin >> var;
                    cout << "\nPower ? " << endl;
                    cin >> pow;
                    term term3 = term(coeff,var,pow);
                    cout << "\nPass to the second polynome ? Press y if yes, or n if no : " << endl;
                    cin >> yn;
                    if(yn == 'y')
                        {
                            pola.setPoly(term1,term2,term3,term4,term5);
                            goto SecondPoly;
                        }


                    cout << "\nCoefficient ? ";
                    cin >> coeff;
                    cout << "\nVariable ? ";
                    cin >> var;
                    cout << "\nPower ? " << endl;
                    cin >> pow;
                    term term4 = term(coeff,var,pow);
                    cout << "\nPass to the second polynome ? Press y if yes, or n if no : " << endl;
                    cin >> yn;
                    if(yn == 'y')
                        {
                            pola.setPoly(term1,term2,term3,term4,term5);
                            goto SecondPoly;
                        }


                    cout << "\nCoefficient ? ";
                    cin >> coeff;
                    cout << "\nVariable ? ";
                    cin >> var;
                    cout << "\nPower ? " << endl;
                    cin >> pow;
                    term term5 = term(coeff,var,pow);
                    cout << "\nPass to the second polynome ? Press y if yes, or n if no : " << endl;
                    cin >> yn;
                    if(yn == 'y')
                        {
                            pola.setPoly(term1,term2,term3,term4,term5);
                            goto SecondPoly;
                        }


                    pola.setPoly(term1,term2,term3,term4,term5);}

                    {SecondPoly:
                        cout << "\n Here we start to complete the second polynome " << endl;
                        cout << "\nCoefficient ? ";
                        cin >> coeff;
                        cout << "\nVariable ? ";
                        cin >> var;
                        cout << "\nPower ? " << endl;
                        cin >> pow;
                        term term6 = term(coeff,var,pow);
                        cout << "\nPass to the multiplication ? Press y if yes, or n if no : " << endl;
                        cin >> yn;
                        if(yn == 'y')
                            {
                                polb.setPoly(term6,term7,term8,term9,term10);
                                goto ThePrinter;
                            }

                        cout << "\nCoefficient ? ";
                        cin >> coeff;
                        cout << "\nVariable ? ";
                        cin >> var;
                        cout << "\nPower ? " << endl;
                        cin >> pow;
                        term term7 = term(coeff,var,pow);
                        cout << "\nPass to the multiplication ? Press y if yes, or n if no : " << endl;
                        cin >> yn;
                        if(yn == 'y')
                            {
                                polb.setPoly(term6,term7,term8,term9,term10);
                                goto ThePrinter;
                            }

                        cout << "\nCoefficient ? ";
                        cin >> coeff;
                        cout << "\nVariable ? ";
                        cin >> var;
                        cout << "\nPower ? " << endl;
                        cin >> pow;
                        term term8 = term(coeff,var,pow);
                        cout << "\nPass to the multiplication ? Press y if yes, or n if no : " << endl;
                        cin >> yn;
                        if(yn == 'y')
                            {
                                polb.setPoly(term6,term7,term8,term9,term10);
                                goto ThePrinter;
                            }

                        cout << "\nCoefficient ? ";
                        cin >> coeff;
                        cout << "\nVariable ? ";
                        cin >> var;
                        cout << "\nPower ? " << endl;
                        cin >> pow;
                        term term9 = term(coeff,var,pow);
                        cout << "\nPass to the multiplication ? Press y if yes, or n if no : " << endl;
                        cin >> yn;
                        if(yn == 'y')
                            {
                                polb.setPoly(term6,term7,term8,term9,term10);
                                goto ThePrinter;
                            }

                        cout << "\nCoefficient ? ";
                        cin >> coeff;
                        cout << "\nVariable ? ";
                        cin >> var;
                        cout << "\nPower ? " << endl;
                        cin >> pow;
                        term term10 = term(coeff,var,pow);
                        cout << "\nPass to the multiplication ? Press y if yes, or n if no : " << endl;
                        cin >> yn;
                        if(yn == 'y')
                            {
                                polb.setPoly(term6,term7,term8,term9,term10);
                                goto ThePrinter;
                            }


                        }
                        ThePrinter:
                            printer(pola,polb);
                            cout << "end" <<endl;






                }

            case 2:
                {
                    cout << "Why ? ;-;";
                    break;
                }

        }

    case 2:
        break;
    }

    return 0;
}
