#ifndef POLY_H_INCLUDED
#define POLY_H_INCLUDED

#include "term.h"

class poly
{
private:
    term polynome[5]; //--> a polynome can be see like a list of term

public:
    poly()
    {

    }

    void setPoly(term  a = term(), term  b = term(), term  c = term(), term  d = term(), term  e = term()) //we fill the array, I added default parameters
    {

        polynome[0] = a;
        polynome[1] = b;
        polynome[2] = c;
        polynome[3] = d;
        polynome[4] = e;
    }

    void setTerms(int index, term t) //If we want to modify only one of them
    {
        polynome[index] = t;

    }

    term getTerms(int index)
    {
        term res = polynome[index];
        return res;
    }

};

#endif // POLY_H_INCLUDED
