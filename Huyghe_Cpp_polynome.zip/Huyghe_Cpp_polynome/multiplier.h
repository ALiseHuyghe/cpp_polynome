#ifndef MULTIPLIER_H_INCLUDED
#define MULTIPLIER_H_INCLUDED

#include <iostream>
#include <iomanip>
#include "poly.h"
#include "term.h"

using namespace std;
term * multiplier(poly a, poly b)  //We cannot return a tab directly, so I use a pointer.
{
    static term pol_c[100];
    int i;
    int j;
    int k = 0;
    for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 5; j++)
                {
                    term terma = a.getTerms(i);
                    term termb = b.getTerms(j);
                    if((terma.getCoeff()!=0)&&(termb.getCoeff()!=0)) //Is this term null ?
                        {
                             if(terma.getVariable()==termb.getVariable())//the simpliest case
                                {
                                    int theC = terma.getCoeff()*termb.getCoeff();
                                    int theP = terma.getPow()+termb.getPow();
                                    char theV = terma.getVariable();
                                    pol_c[k] = term(theC,theV,theP);
                                    k = k+1;

                                }
                                else if(terma.getVariable()!=termb.getVariable()) //the case where we have something like 2x**3 * 4y**5
                                    {
                                        int theC = terma.getCoeff()*termb.getCoeff();
                                        int theP1 = terma.getPow();
                                        int theP2 = termb.getPow();
                                        char theV1 = terma.getVariable();
                                        char theV2 = termb.getVariable();
                                        pol_c[k] = term(theC,theV1,theP1); //We use two place in our array, so k = k+2
                                        pol_c[k+1] = term(0,theV2,theP2);
                                        k = k+2;

                                    }

                        }


                }

        }

    return pol_c;
}

#endif // MULTIPLIER_H_INCLUDED
