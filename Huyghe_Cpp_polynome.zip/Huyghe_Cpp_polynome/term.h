#ifndef TERM_H_INCLUDED
#define TERM_H_INCLUDED

#include <string>
class term
{
private:
    int coeff; //can be positive or negative
    char variable;//the letter
    int pow;//the power

public:

    term(int c=0, char v='-', int p=0)
    {
       coeff = c;
       variable = v;
       pow = p;
    }

    int getCoeff()
    {
        int coe = coeff;
        return coe;
    }

    int getPow()
    {
        int p = pow;
        return p;
    }

    char getVariable()
    {
        char var = variable;
        return var;
    }

    void setCoeff(int c)
    {
        coeff = c;
    }

    void setPow(int p)
    {
        pow = p;

    }

    void setVariable(char v)
    {
        variable = v;
    }


};

#endif // TERM_H_INCLUDED
