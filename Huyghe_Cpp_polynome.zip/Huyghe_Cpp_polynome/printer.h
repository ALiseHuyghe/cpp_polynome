#ifndef PRINTER_H_INCLUDED
#define PRINTER_H_INCLUDED

#include <iostream>
#include <iomanip>
#include "multiplier.h"
#include "poly.h"
#include "term.h"

using namespace std;
//this header is here to print what is returned by multiplier.
//I do this because if I write it in the menu, it will be the hell for reading.
void printer(poly a, poly b)
{
    poly pola = a;
    poly polb = b;
    term *mul;
    mul = multiplier(pola,polb);
    int i;
    for(i=0; i<100;i++)
    {
        if((mul[i].getCoeff()!=0)&&(mul[i+1].getCoeff()==0)) //A coeff =0 means default coeff, 2 coeffs = 0 means we reach the end
            {
                cout << " " << mul[i].getCoeff() << "(" << mul[i].getVariable() << "**" << mul[i].getPow() << ")" <<
                "("<< mul[i+1].getVariable() << "**" << mul[i+1].getPow() << ")" << "+";
                //i = i+1;
            }
        else if ((mul[i].getCoeff()==0)&&(mul[i+1].getCoeff()==0))
            {
                break;
            }
        else
            {
                cout << " " << mul[i].getCoeff() << "(" << mul[i].getVariable() << "**" << mul[i].getPow() << ")" << "+";
            }

    }

}


#endif // PRINTER_H_INCLUDED
